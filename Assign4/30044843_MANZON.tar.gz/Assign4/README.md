CPSC 457 Assignment 4
- To run the two programs (fifo.cpp & robin.cpp),run the makefile.
- The produce output should be run in this format
	./outputFIFO
    ./outputROBIN 
- Enter the input file name on the screen when prompted by the program.