CPSC 457 Assignment 3
To compile the code,run the makefile.
Part1
- The produce output should be run in this format, where numberOfChopstick is between 5-10
	./Assign3_Part1 numberOfChopstick
	Example : ./Assign3_Part1 5
	
Part2
- The produce output should be run in this format
	./Assign3_Composite numberOfThreads
	Example : ./Assign3_Composite 2